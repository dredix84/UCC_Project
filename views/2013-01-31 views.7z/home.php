<?php
	global $dcheck;
	if(!isset($dcheck)) die("<span style=\"color:red\">Restricted Access !!!!</span>");
	session_start();
	if(!isset($_SESSION["userinfo"])){header("location:index.php?route=login");}
	
	$pagetitle = "Home";
?>

Welcome to <?=$_SESSION["userinfo"]["fname"]." ".$_SESSION["userinfo"]["lname"]?>.<br />


<?php echo order_informsales(1, "54461315384"); ?>
