<?php
	global $dcheck;
	if(!isset($dcheck)) die("<span style=\"color:red\">Restricted Access !!!!</span>");\
	session_start();
	if(!isset($_SESSION["userinfo"])){header("location:index.php?route=login");}
	
	$pagetitle = "Order Entry";
	
	
	if(isset($_REQUEST["dosave"])){

		//	Load data into array
		$orders_data["orderentrydate"] = $_REQUEST["orderentrydate"];
		$orders_data["accountmanager"] = $_REQUEST["accountmanager"];
		$orders_data["event_rush"] = $_REQUEST["event_rush"];
		$orders_data["repeatorder"] = $_REQUEST["repeatorder"];
		$orders_data["mustshipbydate"] = $_REQUEST["mustshipbydate"];
		$orders_data["orderinhanddate"] = $_REQUEST["orderinhanddate"];
		$orders_data["taxcode"] = $_REQUEST["taxcode"];
		$orders_data["cust_po"] = $_REQUEST["cust_po"];
		$orders_data["customer_id"] = $_REQUEST["customer_id"];
		$orders_data["companyb"] = $_REQUEST["companyb"];
		$orders_data["attentionb"] = $_REQUEST["attentionb"];
		$orders_data["addressb"] = $_REQUEST["addressb"];
		$orders_data["address2b"] = $_REQUEST["address2b"];
		$orders_data["cityb"] = $_REQUEST["cityb"];
		$orders_data["stateb"] = $_REQUEST["stateb"];
		$orders_data["zipcodeb"] = $_REQUEST["zipcodeb"];
		$orders_data["companys"] = $_REQUEST["companys"];
		$orders_data["attentions"] = $_REQUEST["attentions"];
		$orders_data["addresss"] = $_REQUEST["addresss"];
		$orders_data["address2s"] = $_REQUEST["address2s"];
		$orders_data["citys"] = $_REQUEST["citys"];
		$orders_data["states"] = $_REQUEST["states"];
		$orders_data["zipcodes"] = $_REQUEST["zipcodes"];
		$orders_data["ordernote"] = $_REQUEST["ordernote"];
		
		$wassaved = false;
		if($_REQUEST["orderid"] == ""){		//New record
			$wassaved = $db->insert('orders',$orders_data);
			order_informsales($_REQUEST["accountmanager"], $_REQUEST["cust_po"]);	//Used to send  the email to the sales person.
		}else{		//Update record
			$wassaved = $db->update('orders',$orders_data, "id = ".$db->escape($_REQUEST["orderid"]));
		}
		if($wassaved){$msg = "The data was saved.";}
		else{$msg = "There was a error while attempting to save.";}
	}
	
?>
	<?php if(isset($msg)){ ?>
	<div style="margin-top: 20px; padding: 0 .7em;" class="ui-state-highlight ui-corner-all">
		<p><span style="float: left; margin-right: .3em;" class="ui-icon ui-icon-info"></span>
		<strong><?=$msg?></strong></p>
	</div>
    <?php } ?>
    
<form method="post" action="index.php?route=oentry" name="orderForm" onsubmit="return yav.performCheck('orderForm', rules, 'classic');">
	<input name="dosave" value="yes" type="hidden" /><input name="orderid" value="" type="hidden" />
    <table width="100%" border="0">
      <tr>
        <td>Order Entry Date:</td>
        <td><input type="text" class="jdate	oinput" name="orderentrydate" id="" readonly="readonly" /></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Account Manager:</td>
        <td>
            <select class="chzn-select-deselect" name="accountmanager" style="width: 150px">
                <option value="">Choose One</option>
                <?php
                    $db->query("SELECT u.`id`, concat(u.`fname`, ' ', u.`lname`) as accman FROM users u WHERE account_manager = 1 AND u.status = 1");
                    $srecords = $db->fetch_assoc_all();
                    foreach($srecords as $srow){
                        echo "\n\t<option value=\"".$srow["id"]."\">".$srow["accman"]."</option>";
                    }
                
                ?>
            </select>
        </td>
        <td>&nbsp;</td>
        <td>Event/Rush: </td>
        <td>
            <select name="event_rush">
                <option value="">Choose One</option>
                <?php
                    $db->query("SELECT `id`, `description` FROM event_rush");
                    $srecords = $db->fetch_assoc_all();
                    foreach($srecords as $srow){
                        echo "\n\t<option value=\"".$srow["id"]."\">".$srow["description"]."</option>";
                    }
                
                ?>
            </select>
        </td>
      </tr>
      <tr>
        <td>Must be shipped by: </td>
        <td><input type="text" class="jdate	oinput" name="mustshipbydate" id="" readonly="readonly" /></td>
        <td>&nbsp;</td>
        <td>Order In-Hands Date: </td>
        <td><input type="text" class="jdate	oinput" name="orderinhanddate" id="" readonly="readonly" /></td>
      </tr>
      <tr>
        <td>Is a repeat order:</td>
        <td>
            <input type="radio" name="repeatorder" id="repeato1" value="1" /> <label for="repeato1">Yes</label> 
            <input type="radio" name="repeatorder" id="repeato0" value="0" /> <label for="repeato0">No</label> 
        </td>
        <td>&nbsp;</td>
        <td>Tax Code: </td>
        <td>
            <select name="taxcode">
                <option value="">Choose One</option>
                <?php
                    $db->query("SELECT `id`, `code` FROM taxcode");
                    $srecords = $db->fetch_assoc_all();
                    foreach($srecords as $srow){
                        echo "\n\t<option value=\"".$srow["id"]."\">".$srow["code"]."</option>";
                    }
                
                ?>
            </select>
        </td>
      </tr>
    </table>
    
    <h3 class="sechead">Customer Information</h3>
    <table width="100%" border="0">
      <tr>
        <td>Customer PO#: <input type="text" class="oinput" name="cust_po" id="cust_po" /></td>
        <td>&nbsp;</td>
        <td colspan="3">Ordered By:  	
            <select class="chzn-select-deselect" id="customerid" name="customer_id" style="width:200px">
                <option value="">Choose One</option>
                <?php
                    $db->query("SELECT id, concat(`fname`, ' ',`lname`) as fullname  FROM customers;");
                    $srecords = $db->fetch_assoc_all();
                    foreach($srecords as $srow){
                        echo "\n\t<option value=\"".$srow["id"]."\">".$srow["fullname"]."</option>";
                    }
                
                ?>
            </select>   <div id="getcustbusy"></div>  
        </td>
      </tr>
      <tr>
        <td colspan="2">Customer Bill To: </td>
        <td>&nbsp;</td>
        <td colspan="2">Customer Shipp To Address: </td>
      </tr>
      <tr>
        <td colspan="2" class="infield">
            <input type="text" class="oinput" name="companyb" id="companyb" style="width:100%" title="Company"/>
            <input type="text" class="oinput" name="attentionb" id="attentionb" style="width:100%" title="Attention" />
            <input type="text" class="oinput" name="addressb" id="addressb" style="width:100%" title="Address" />
            <input type="text" class="oinput" name="address2b" id="address2b" style="width:100%" title="Address 2" />
            <input type="text" class="oinput" name="cityb" id="cityb" style="width:100%" title="City" />
            <select style="width:48%" class="oinput" id="stateb" name="stateb">
                <option value="">State</option>
                <?php
                    $db->query("SELECT `code`, `name` FROM state");
                    $srecords = $db->fetch_assoc_all();
                    foreach($srecords as $srow){
                        echo "\n\t<option value=\"".$srow["code"]."\">".$srow["name"]."</option>";
                    }
                ?>
            </select>
            <input type="text" class="oinput" name="zipcodeb" id="zipcodeb" style="width:48%;float:right" title="Zipcode" />
        </td>
        <td>&nbsp;</td>
        <td colspan="2" class="infield">
            <input type="text" class="oinput" name="companys" id="companys" style="width:100%" title="Company" />
            <input type="text" class="oinput" name="attentions" id="attentions" style="width:100%" title="Attention" />
            <input type="text" class="oinput" name="addresss" id="addresss" style="width:100%" title="Address" />
            <input type="text" class="oinput" name="address2s" id="address2s" style="width:100%" title="Address 2" />
            <input type="text" class="oinput" name="citys" id="citys" style="width:100%" title="City" />
            <select style="width:48%" class="oinput" id="states" name="states">
                <option value="">State</option>
                <?php 
                    $db->query("SELECT `code`, `name` FROM state");
                    $srecords = $db->fetch_assoc_all();
                    foreach($srecords as $srow){
                        echo "\n\t<option value=\"".$srow["code"]."\">".$srow["name"]."</option>";
                    }
                ?>
            </select>
            <input type="text" class="oinput" name="zipcodes" id="zipcodes" style="width:48%;float:right" title="Zipcode" />
        </td>
      </tr>
      <tr>
        <td colspan="2"><input type="checkbox" id="shipissame" value="0" /> <label for="shipissame">Also use as "Ship To" address</label></td>
        <td>&nbsp;</td>
        <td colspan="2"><input type="checkbox" id="shipadd" /> <label for="shipadd">Ship Multiple Address</label></td>
      </tr>
    </table>
    
    
    
    <h3 class="sechead">Product & Vendor Information</h3>
    <div id="products">
    
    </div>
    <div id="TempDiv" style="display:none">
    
    </div>
    <a onclick="addproduction()" class="jbtn"><img src="images/add.png" align="absmiddle" /> Add Product</a>
    <br /><br />
    Order Notes:
    <textarea style="width:100%" rows="5" name="ordernote" id="ordernote"></textarea>
    <br /><br /> 
    
    <input type="checkbox" id="iagree" />
    <label for="iagree" class="corange">I have checked quantities, imprints color &amp; time frame for the product with the vendor. I am also aware that  I am responsible personally and financially for all errors & ommissions.</label>
    <br /><br />
    
    <center><input type="submit" class="jbtn" /></center>
</form> 
<a onclick="addvendordiag()" class="jbtn">Test</a>
    
    

    <div id="dialog_addvendor" title="Add Vendor">
    	<form name="vForm">
        <table width="100%" border="0">
          <tr>
            <td>Name</td>
            <td><input type="text"  id="vname" name="vname" class="vinput"/></td>
          </tr>
          <tr>
            <td>Contact Person</td>
            <td><input type="text"  id="vcontact" name="vcontact" class="vinput"/></td>
          </tr>
          <tr>
            <td>Phone</td>
            <td><input type="text"  id="vphone" name="vphone" class="vinput"/></td>
          </tr>
          <tr>
            <td>Other Info</td>
            <td><textarea name="voinfo" id="voinfo" style="width: 100%;" rows="5" class="vinput"></textarea></td>
          </tr>
          <tr>
            <td colspan="2"><center><a class="jbtn" onclick="vendorsave();">Save Vendor</a></center></td>
          </tr>
        </table>
    	</form>
    </div>

    
         
 <script>
	$(function() {
		$( ".jdate" ).datepicker();
		$( ".jdate" ).datepicker( "option", "dateFormat", "yy-mm-dd");
		$(".chzn-select-deselect").chosen({allow_single_deselect:true});
	});
	
	function makeniceselect(){
		$(".chzn-select-deselect").chosen({allow_single_deselect:true});
	}
	
function addproduction(){
	//Used to get a product with JSON
	var ajax_load = "<img src='img/load.gif' alt='loading...' />";
	var loadUrl = "index.php?route=json_product&pagetype=ajax";
	//$("#products").append(ajax_load).load(loadUrl);
	$('#TempDiv').load(loadUrl, function(){
		$('#products').append($('#TempDiv').html());
		$(".chzn-select-deselect").chosen({allow_single_deselect:true});
		$( ".jbtn" ).button();
	});
	
	
	/*$("#products") 
        .load(loadUrl, null, function(responseText){  
        $("#products").append(responseText);
	}); 
	return false; 	*/
}

function removeblock(bid){
	$("#"+bid).hide("slow").remove();
}
/*
$.getJSON("index.php?route=products&pagetype=ajax",function(msg){

    alert("TotalClass : "+msg.u1);
    $.each(msg,function(k, v){
        alert(k+ " - "+v)
    });
});*/
	$("#customerid").change(function( event ) {
		getcustaddress();
	});
	$("#shipissame").click(function( event ) {
		sameaddress();
	});
	
function getcustaddress(){
	$("#getcustbusy").html("<img src='images/gettingd.png' alt='Busy' />");
	$.getJSON("index.php?route=json_getcustomer&pagetype=ajax&custid=" + $("#customerid").val(),function(msg){
		$.each(msg,function(k, v){
			if(v == "" || v == null){
				//alert(k+ " - "+v);
				$("#"+k).val("");
			}else{
				$("#"+k).val(v);
			}
			
		});
	});
	$("#getcustbusy").html("");	
}

function sameaddress(){	
	var istatus = true;
	if($('#shipissame').val() == 0) {
		$("#companys").val($("#companyb").val());
		$("#attentions").val($("#attentionb").val());
		$("#addresss").val($("#addressb").val());
		$("#address2s").val($("#address2b").val());
		$("#citys").val($("#cityb").val());
		$("#states").val($("#stateb").val());
		$("#zipcodes").val($("#zipcodeb").val());
		istatus = true;
		$('#shipissame').val(1);
	} else {
		istatus = false;
		$('#shipissame').val(0);
	}

	$("#companys").prop('disabled', istatus);
	$("#attentions").prop('disabled', istatus);
	$("#addresss").prop('disabled', istatus);
	$("#address2s").prop('disabled', istatus);
	$("#citys").prop('disabled', istatus);
	$("#states").prop('disabled', istatus);
	$("#zipcodes").prop('disabled', istatus);
	
	/*
	.val($("#companyb").val());
	$("#attentions").val($("#attentionb").val());
	$("#addresss").val($("#addressb").val());
	$("#address2s").val($("#address2b").val());
	$("#citys").val($("#cityb").val());
	$("#states").val($("#stateb").val());
	$("#zipcodes").val($("#zipcodeb").val());*/
}

//Infield text
$('.infield input[type="text"]').each(function(){
 
    this.value = $(this).attr('title');
    $(this).addClass('text-label');
 
    $(this).focus(function(){
        if(this.value == $(this).attr('title')) {
            this.value = '';
            $(this).removeClass('text-label');
        }
    });
 
    $(this).blur(function(){
        if(this.value == '') {
            this.value = $(this).attr('title');
            $(this).addClass('text-label');
        }
    });
});
	//Setting up dialog for adding vendors
	$( "#dialog_addvendor" ).dialog({
		autoOpen: false,
		modal: true,
		width: 400
	});
	$( ".jbtn" ).button();

	function addvendordiag($blockid){
		$("#tempwork").val($blockid);
		$( "#dialog_addvendor" ).dialog( "open" );
	}
	
	function vendorsave(){
		//Used to do ajax request to save vendor information
		if(yav.performCheck('vForm', vrules, 'classic')){
			$.post(  
				"index.php?route=ajax_vendorsave&pagetype=ajax",  
				{vname: $("#vname").val(), vcontact: $("#vcontact").val(), vphone: $("#vphone").val(), voinfo: $("#voinfo").val()},  
				function(responseText){  
					$("#vendorctrl_" + $("#tempwork").val()).html(responseText); 
					alert($("#vname").val() + "was saved.");
					$(".vinput").val("");
					$("#tempwork").val("");
					$( "#dialog_addvendor" ).dialog( "close" );
					$(".chzn-select-deselect").chosen({allow_single_deselect:true});
				},  
				"html"  
			);
		}
	}
	
	function calc_netprice(blockid){
		var netrpice = parseFloat($("#qty_"+blockid).val()) * parseFloat($("#retailprice_"+blockid).val())
		$("#netprice_"+blockid).val(netrpice);
	}

    var rules=new Array();
	rules[0]='orderentrydate:Order Entry Date|required';
	rules[1]='accountmanager:Account Manager|required';
	rules[2]='event_rush:Event/Rush|required';
	rules[3]='repeatorder:Repeat Order|required';
	rules[4]='mustshipbydate:Must Ship By|required';
	rules[5]='orderinhanddate:Order in hand Date|required';
	rules[6]='taxcode:Tax Code|required';
	rules[7]='cust_po:Customer PO Number|required';
	rules[8]='customer_id:Customer|required';
	rules[9]='addressb:addressb|required';
	rules[10]='cityb:cityb|required';
	rules[11]='stateb:stateb|required';
	rules[12]='addresss:addresss|required';
	rules[13]='citys:citys|required';
	rules[14]='states:states|required';
	rules[15]='iagree|required|You must agree to the terms before submitting.';
	
	var vrules=new Array();
	vrules[0]='vname:Vendor Name|required';
</script>
<input type="hidden" id="tempwork" />

